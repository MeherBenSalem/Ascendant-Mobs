package tn.mbs.ascendantmobs.init;

import tn.mbs.ascendantmobs.configuration.MobsListConfigConfiguration;
import tn.mbs.ascendantmobs.configuration.MobsLevelsMainConfigConfiguration;
import tn.mbs.ascendantmobs.configuration.CustomDimensionsConfigConfiguration;
import tn.mbs.ascendantmobs.AscendantMobsMod;

import net.neoforged.fml.event.lifecycle.FMLConstructModEvent;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.ModContainer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.IEventBus;

@Mod(AscendantMobsMod.MODID)
@EventBusSubscriber(modid = AscendantMobsMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class AscendantMobsModConfigs {
	private static ModContainer modContainer;

	public AscendantMobsModConfigs(IEventBus modEventBus, ModContainer container) {
		setModContainer(container);
	}

	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			modContainer.registerConfig(ModConfig.Type.COMMON, MobsLevelsMainConfigConfiguration.SPEC, "AscendantMobs/main_config.toml");
			modContainer.registerConfig(ModConfig.Type.COMMON, MobsListConfigConfiguration.SPEC, "AscendantMobs/list_config.toml");
			modContainer.registerConfig(ModConfig.Type.COMMON, CustomDimensionsConfigConfiguration.SPEC, "AscendantMobs/config_dims.toml");
		});
	}

	public static void setModContainer(ModContainer container) {
		modContainer = container;
	}
}
